package com.example.newbmi;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Pedometer;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;


public class Ranger extends Form implements HandlesEventDispatching {

    private
    Pedometer counter;
    Integer Steps=0;
    Double Distance=0.0;
    Button start, stop, reset, goBack;
    Label headingAtTop, stepCountText, disCountText;
    TextBox stepCount, distanceCount;
    HorizontalArrangement stepSplit, disCountSplit, buttonsSplit;

    VerticalScrollArrangement stepper;

    protected void $define()
    {
        this.Sizing("Responsive");
        this.BackgroundColor(COLOR_GRAY);

        stepper = new VerticalScrollArrangement(this);
        stepper.WidthPercent(100);
        stepper.Height(LENGTH_FILL_PARENT);
        stepper.AlignHorizontal(Component.ALIGNMENT_CENTER);

        goBack = new Button (stepper) ;
        goBack.Text("BMI  ");
        goBack.HeightPercent(10);
        goBack.WidthPercent(100);
        goBack.TextColor(COLOR_ORANGE);
        goBack.TextAlignment(ALIGNMENT_OPPOSITE);
        goBack.FontSize(30);

        headingAtTop = new Label(stepper);
        headingAtTop.Text("STEPPER");
        headingAtTop.WidthPercent(100);
        headingAtTop.TextAlignment(ALIGNMENT_CENTER);
        headingAtTop.HeightPercent(10);
        headingAtTop.FontSize(50);
        headingAtTop.TextColor(COLOR_ORANGE);

        stepSplit = new HorizontalArrangement(stepper);
        stepSplit.WidthPercent(LENGTH_FILL_PARENT);
        stepSplit.HeightPercent(10);

        stepCountText = new Label (stepSplit);
        stepCountText.Text("Steps:   ");
        stepCountText.HeightPercent(10);
        stepCountText.WidthPercent(50);
        stepCountText.TextColor(COLOR_ORANGE);
        stepCountText.TextAlignment(Component.ALIGNMENT_OPPOSITE);
        stepCountText.FontSize(30);

        stepCount = new TextBox(stepSplit);
        stepCount.WidthPercent(50);
        stepCount.HeightPercent(10);
        stepCount.FontSize(30);
        stepCount.TextColor(Component.COLOR_ORANGE);
        stepCount.Text(Steps.toString());
        stepCount.TextAlignment(Component.ALIGNMENT_NORMAL);

        disCountSplit = new HorizontalArrangement(stepper);
        disCountSplit.WidthPercent(LENGTH_FILL_PARENT);
        disCountSplit.HeightPercent(10);

        disCountText = new Label (disCountSplit);
        disCountText.Text("Distance:   ");
        disCountText.HeightPercent(10);
        disCountText.WidthPercent(50);
        disCountText.TextColor(COLOR_ORANGE);
        disCountText.TextAlignment(Component.ALIGNMENT_OPPOSITE);
        disCountText.FontSize(30);

        distanceCount = new TextBox(disCountSplit);
        distanceCount.WidthPercent(50);
        distanceCount.HeightPercent(10);
        distanceCount.FontSize(30);
        distanceCount.TextColor(Component.COLOR_ORANGE);
        distanceCount.Text(Steps.toString());
        distanceCount.TextAlignment(Component.ALIGNMENT_NORMAL);

        buttonsSplit = new HorizontalArrangement(stepper);
        buttonsSplit.WidthPercent(LENGTH_FILL_PARENT);
        buttonsSplit.HeightPercent(10);

        start = new Button(buttonsSplit);
        start.HeightPercent(10);
        start.WidthPercent(35);
        start.Text("start");
        start.TextColor(Component.COLOR_ORANGE);

        stop = new Button(buttonsSplit);
        stop.HeightPercent(10);
        stop.WidthPercent(35);
        stop.Text("stop");
        stop.TextColor(Component.COLOR_ORANGE);

        reset = new Button(buttonsSplit);
        reset.HeightPercent(10);
        reset.WidthPercent(35);
        reset.Text("reset");
        reset.TextColor(Component.COLOR_ORANGE);



        counter = new Pedometer(stepper);
        EventDispatcher.registerEventForDelegation(this, formName, "Click");
        EventDispatcher.registerEventForDelegation(this, formName, "WalkStep");
    }
    @Override
    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params)
    {
        switch (eventName)
        {
            case "Click":
                if (component.equals(start))
                {
                    counter.Start();
                    return true;
                }
                else if (component.equals(stop))
                {
                    counter.Stop();
                    return true;
                } else if (component.equals(reset))
                {
                    counter.Reset();
                    Steps = 0;
                    Distance = 0.0;
                    stepCount.Text(Steps.toString());
                    distanceCount.Text(String.format("%.2f", Distance) + " M");
                    return true;
                }
                else if (component.equals(goBack)) {
                    switchForm("MainActivity");
                    return true;
                }
                break;
            case "WalkStep":
            {
                Steps = counter.WalkSteps();
                stepCount.Text(Steps.toString());
                Distance = Steps * 0.762;
                distanceCount.Text(String.format("%.2f", Distance) + " M");
            }
        }
        return false;
    }

}