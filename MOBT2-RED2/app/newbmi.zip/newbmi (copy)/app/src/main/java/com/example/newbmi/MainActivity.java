package com.example.newbmi;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.PasswordTextBox;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.WebViewer;
import com.google.appinventor.components.runtime.util.Ev3Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;



public class MainActivity extends Form implements HandlesEventDispatching {

    public

    TextBox massBox, heightBox;
    Button calcButton, walky;
    Label resultAtBottom, headingAtTop, blockAtBottom, problemAtBottom;
    HorizontalArrangement dataEntryArrangement, resultSplit;
    VerticalScrollArrangement mainArrangement;

    protected void $define() {

        this.Sizing("Responsive");
        this.BackgroundColor(COLOR_GRAY);

        mainArrangement=new VerticalScrollArrangement(this);
        mainArrangement.WidthPercent(100);
        mainArrangement.Height(LENGTH_FILL_PARENT);
        mainArrangement.AlignHorizontal(Component.ALIGNMENT_CENTER);

        walky = new Button (mainArrangement);
        walky.Text("STEP COUNT  ");
        walky.HeightPercent(10);
        walky.WidthPercent(100);
        walky.TextColor(Component.COLOR_ORANGE);
        walky.TextAlignment(Component.ALIGNMENT_OPPOSITE);
        walky.FontSize(30);

        headingAtTop= new Label(mainArrangement);
        headingAtTop.Text("\nBMI Calculator");
        headingAtTop.WidthPercent(100);
        headingAtTop.TextAlignment(ALIGNMENT_CENTER);
        headingAtTop.HeightPercent(20);
        headingAtTop.FontSize(50);
        headingAtTop.TextColor(COLOR_ORANGE);

        dataEntryArrangement = new HorizontalArrangement(mainArrangement);
        dataEntryArrangement.WidthPercent(LENGTH_FILL_PARENT);
        dataEntryArrangement.HeightPercent(10);

        massBox=new TextBox(dataEntryArrangement);
        massBox.WidthPercent(50);
        massBox.HeightPercent(10);
        massBox.FontSize(20);
        massBox.TextAlignment(ALIGNMENT_CENTER);
        massBox.Hint("Weight in KG");
        massBox.TextColor(COLOR_WHITE);

        heightBox=new TextBox(dataEntryArrangement);
        heightBox.WidthPercent(50);
        heightBox.HeightPercent(10);
        heightBox.FontSize(20);
        heightBox.Hint("Height in CM");
        heightBox.TextAlignment(ALIGNMENT_CENTER);
        heightBox.TextColor(COLOR_WHITE);

        calcButton= new Button(mainArrangement);
        calcButton.Text("CALCULATE");
        calcButton.HeightPercent(10);
        calcButton.Width(LENGTH_FILL_PARENT);
        calcButton.TextColor(COLOR_ORANGE);
        calcButton.TextAlignment(ALIGNMENT_CENTER);
        calcButton.FontSize(20);

        resultSplit = new HorizontalArrangement(mainArrangement);
        resultSplit.WidthPercent(LENGTH_FILL_PARENT);
        resultSplit.HeightPercent(10);

        blockAtBottom = new Label(resultSplit);
        blockAtBottom.Text("BMI:   ");
        blockAtBottom.HeightPercent(10);
        blockAtBottom.WidthPercent(50);
        blockAtBottom.FontSize(20);
        blockAtBottom.TextColor(COLOR_WHITE);
        blockAtBottom.TextAlignment(Component.ALIGNMENT_OPPOSITE);

        resultAtBottom=new Label(resultSplit);
        resultAtBottom.HeightPercent(10);
        resultAtBottom.WidthPercent(50);
        resultAtBottom.FontSize(50);
        resultAtBottom.TextAlignment(ALIGNMENT_NORMAL);
        resultAtBottom.TextColor(Component.COLOR_ORANGE);

        problemAtBottom=new Label(mainArrangement);
        problemAtBottom.HeightPercent(10);
        problemAtBottom.WidthPercent(100);
        problemAtBottom.FontSize(100);
        problemAtBottom.TextAlignment(ALIGNMENT_CENTER);


        EventDispatcher.registerEventForDelegation(this, formName, "Click");

    }

    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params) {

        System.err.print("dispatchEvent: " + formName + " [" + component.toString() + "] [" + componentName + "] " + eventName);
        if (eventName.equals("Click")) {
            if (component.equals(calcButton)) {
                calculateTheBMI();
                return true;
            }

            else if (component.equals(walky)) {
                switchForm("Ranger");
                return true;
            }
        }

        return false;
    }
    void calculateTheBMI() {
        Double weight = 0.0, height = 0.0, bmi_result;

        try {
            if (!massBox.Text().isEmpty()) {
                weight = Double.valueOf(massBox.Text());
            }
            if (!heightBox.Text().isEmpty()) {
                height = Double.valueOf(heightBox.Text());
            }


            if ((!height.equals((double) 0)) && (!weight.equals((double) 0))) {
                bmi_result = weight / height / height * 10000;
                DecimalFormat df = new DecimalFormat();
                df.setMaximumFractionDigits(1);
                resultAtBottom.Text(df.format(bmi_result));

                if (bmi_result <= 0) {
                    blockAtBottom.Text("\nIncorrect input  ");
                    blockAtBottom.TextColor(COLOR_BLUE);
                }
                else if (bmi_result > 0 && bmi_result < 18.50) {
                    blockAtBottom.Text("\nUnder weight  ");
                    blockAtBottom.TextColor(COLOR_BLUE);
                }
                else if (bmi_result >= 18.51 && bmi_result <= 24.99) {
                    blockAtBottom.Text("\nNormal weight  ");
                    blockAtBottom.TextColor(COLOR_GREEN);
                }
                else if (bmi_result >= 25.00 && bmi_result <= 29.99) {
                    blockAtBottom.Text("\nOver weight  ");
                    blockAtBottom.TextColor(COLOR_ORANGE);
                }
                else if (bmi_result >= 30.00 && bmi_result <= 34.99) {
                    blockAtBottom.Text("\nObese  ");
                    blockAtBottom.TextColor(COLOR_YELLOW);
                }
                else if (bmi_result > 35.00) {
                    blockAtBottom.Text("\nExtreme obese  ");
                    blockAtBottom.TextColor(COLOR_RED);
                }
            }
        }
        catch(NumberFormatException e) {
            problemAtBottom.FontSize(10);
            problemAtBottom.Text(e.toString());
        }

    }

}